package ejercicio6;

public class Cuenta {

}
