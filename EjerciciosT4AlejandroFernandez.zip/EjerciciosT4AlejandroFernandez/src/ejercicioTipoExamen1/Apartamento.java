package ejercicioTipoExamen1;

public class Apartamento extends Habitacion  {

	private boolean contratar;
	
	public Apartamento(double precioBase, boolean ocupado, String nombreCliente, int diasOcupacion, int numOcupantes,
			boolean contratar) {
		super(precioBase, ocupado, nombreCliente, diasOcupacion, numOcupantes);
		this.contratar = contratar;
	}

	public boolean isContratar() {
		return contratar;
	}

	public void setContratar(boolean contratar) {
		this.contratar = contratar;
	}

	@Override
	public String toString() {
		return "Apartamento [contratar=" + contratar + "]";
	}
	
	public double contratarServicios(double precio) {
		if(contratar) {
			return super.getPrecioBase()+precio;
		}else {
			return super.getPrecioBase();
		}
	}
	
	public double calcularHabitacion(double porc,double precio) {
		return super.calcularHabitacion(porc, precio)+contratarServicios(precio);
	}
	

}
