package ejercicio8c;

import java.util.Random;

public class Sorteo {

	private Decimo d;
	private int ganador;

	public Sorteo() {

	}

	public Sorteo(Decimo d, int ganador) {
		super();
		this.d = d;
		this.ganador = ganador;
	}

	public Decimo getD() {
		return d;
	}

	public void setD(Decimo d) {
		this.d = d;
	}

	public int getGanador() {
		return ganador;
	}

	public void setGanador(int ganador) {
		this.ganador = ganador;
	}

	@Override
	public String toString() {
		return "Sorteo [d=" + d + ", ganador=" + ganador + "]";
	}

	public void generarAleatorioDecimo(int hasta, int desde) {
		Random r = new Random(System.nanoTime());

		d.setNum(r.nextInt(hasta - desde + 1) + desde);

	}

	public void generarAleatorioGanador(int hasta, int desde) {
		Random r = new Random(System.nanoTime());

		setGanador(r.nextInt(hasta - desde + 1) + desde);
	}

	public int mostrarDecimo(int decimo) {
		return d.getNum();
	}

	public int mostrarGanador(int ganador) {
		return getGanador();
	}

	public boolean comprobarDecimo() {
		if (d.getNum() == getGanador()) {
			return true;
		} else {
			return false;
		}
	}

	public void mostrarComprobarDecimo(boolean b) {
		if (b) {
			System.out.println("Has ganado el primer premio");
		} else {
			System.out.println("Vaya que pena");
		}
	}

}
