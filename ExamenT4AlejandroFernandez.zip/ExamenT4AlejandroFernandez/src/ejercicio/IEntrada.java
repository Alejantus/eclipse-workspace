package ejercicio;

public interface IEntrada {
	
	public double calcularPrecioEntrada();

}
